from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class WalletTrade(BaseModel):
    wallet_trade_id: str
    wallet: str | None = None
    token_mint: str | None = None
    pool_address: str | None = None
    side: str | None = None
    token_amount: float | None = None
    quote_amount: float | None = None
    price_usd: float | None = None
    observed_at: datetime
    source_name: str
    raw_source_event_id: str
    market_snapshot_id: str | None = None
    fees_estimate: float | None = None
    confidence: str = "unknown"
    quality_flags: list[str] = Field(default_factory=list)
    reconstruction_method: str
    eligible_for_high_confidence_evaluation: bool = False
    created_at: datetime


class WalletMetricSnapshot(BaseModel):
    wallet_metric_snapshot_id: str
    wallet: str
    calculated_at: datetime
    trade_count: int = 0
    closed_trade_count: int = 0
    realized_pnl_estimate: float | None = None
    unrealized_inventory: dict[str, Any] = Field(default_factory=dict)
    net_pnl_estimate: float | None = None
    win_rate_estimate: float | None = None
    expectancy_estimate: float | None = None
    payoff_ratio: float | None = None
    average_win: float | None = None
    average_loss: float | None = None
    holding_time_summary: dict[str, Any] = Field(default_factory=dict)
    position_sizing_summary: dict[str, Any] = Field(default_factory=dict)
    sample_size: int = 0
    recency_seconds: float | None = None
    evidence_quality: str = "unknown"
    confidence: str = "unknown"
    quality_flags: list[str] = Field(default_factory=list)
    source_refs: list[str] = Field(default_factory=list)
    candidate_evidence_only: bool = True
    created_at: datetime


class WalletProfile(BaseModel):
    wallet_profile_id: str
    wallet: str
    metrics_snapshot_id: str | None = None
    label: str
    label_confidence: str = "unknown"
    candidate_score: float | None = None
    evidence_quality: str = "unknown"
    degradation_status: str = "unknown"
    sample_size: int = 0
    recency_seconds: float | None = None
    source_refs: list[str] = Field(default_factory=list)
    explanation: dict[str, Any] = Field(default_factory=dict)
    included_reasons: list[str] = Field(default_factory=list)
    excluded_reasons: list[str] = Field(default_factory=list)
    last_updated_at: datetime
    candidate_evidence_only: bool = True
    created_at: datetime


class WalletCluster(BaseModel):
    wallet_cluster_id: str
    relation_type: str
    wallets: list[str] = Field(default_factory=list)
    token_mint: str | None = None
    evidence_refs: list[str] = Field(default_factory=list)
    confidence: str = "unknown"
    quality_flags: list[str] = Field(default_factory=list)
    flags: list[str] = Field(default_factory=list)
    created_at: datetime
