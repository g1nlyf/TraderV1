from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime
from statistics import mean
from typing import Any

from walletscarper.stage2.clock import Clock, SystemClock, isoformat_utc
from walletscarper.stage2.db import Stage2Database
from walletscarper.stage2.db.json import dumps_json
from walletscarper.stage2.ids import new_id


class WalletIntelligenceService:
    def __init__(self, database: Stage2Database, clock: Clock | None = None):
        self.database = database
        self.clock = clock or SystemClock()

    async def reconstruct_wallet_trade_from_raw_event(self, raw_source_event_id: str) -> str:
        event = await self.database.fetchone("SELECT * FROM raw_source_events WHERE raw_source_event_id = ?", (raw_source_event_id,))
        if not event:
            raise ValueError(f"raw source event not found: {raw_source_event_id}")
        payload = _loads_dict(event["payload_json"])
        metadata = _loads_dict(event["quality_metadata_json"])
        attrs = payload.get("attributes") if isinstance(payload.get("attributes"), dict) else payload
        market = await self.database.fetchone(
            "SELECT * FROM market_snapshots WHERE raw_source_event_id = ? ORDER BY created_at DESC LIMIT 1",
            (raw_source_event_id,),
        )
        wallet = _text(attrs.get("wallet") or attrs.get("maker") or attrs.get("trader") or attrs.get("user") or attrs.get("sender") or attrs.get("owner"))
        token_mint = _text(attrs.get("token_mint") or attrs.get("token") or attrs.get("token_0") or (market or {}).get("token_mint"))
        pool_address = _text(attrs.get("pool_address") or attrs.get("pool") or attrs.get("pair_address") or (market or {}).get("pool_address"))
        side = _side(attrs.get("side") or attrs.get("type") or attrs.get("kind"))
        token_amount = _float(attrs.get("token_amount") or attrs.get("base_amount") or attrs.get("amount") or attrs.get("amount_0"))
        quote_amount = _float(attrs.get("quote_amount") or attrs.get("quote_volume") or attrs.get("amount_usd") or attrs.get("volume_usd"))
        price_usd = _float(attrs.get("price_usd") or attrs.get("price") or attrs.get("price_0_usd") or (market or {}).get("price_usd"))
        flags = _unique(list(_loads_list(metadata.get("quality_flags"))) + list(_loads_list((market or {}).get("quality_flags_json"))))
        if not wallet:
            flags.append("missing_wallet")
        if not token_mint:
            flags.append("missing_token_mint")
        if not side:
            flags.append("uncertain_side")
        if token_amount is None:
            flags.append("missing_token_amount")
        if price_usd is None:
            flags.append("missing_price_usd")
        if "missing_observed_at" in flags:
            flags.append("weak_trade_timestamp")
        confidence = _confidence(str(event.get("confidence") or "unknown"), flags)
        eligible = confidence in {"high", "medium"} and not (set(flags) & {"missing_wallet", "uncertain_side", "missing_token_amount", "missing_price_usd", "weak_trade_timestamp"})
        trade_id = new_id("wallet_trade")
        await self.database.execute(
            """
            INSERT INTO wallet_trades(
              wallet_trade_id, wallet, token_mint, pool_address, side, token_amount,
              quote_amount, price_usd, observed_at, source_name, raw_source_event_id,
              market_snapshot_id, fees_estimate, confidence, quality_flags_json,
              reconstruction_method, eligible_for_high_confidence_evaluation, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                trade_id,
                wallet,
                token_mint,
                pool_address,
                side,
                token_amount,
                quote_amount,
                price_usd,
                event["observed_at"],
                event["source_name"],
                raw_source_event_id,
                (market or {}).get("market_snapshot_id"),
                _float(attrs.get("fees") or attrs.get("fee_usd")),
                confidence,
                dumps_json(_unique(flags)),
                "stage2_raw_event_observed_trade_reconstruction",
                1 if eligible else 0,
                isoformat_utc(self.clock.now()),
            ),
        )
        return trade_id

    async def calculate_wallet_metrics(self, wallet: str) -> str:
        trades = await self.database.fetchall(
            "SELECT * FROM wallet_trades WHERE wallet = ? ORDER BY observed_at, created_at, wallet_trade_id",
            (wallet,),
        )
        flags: list[str] = []
        source_refs = [row["raw_source_event_id"] for row in trades]
        if not trades:
            flags.append("no_reconstructed_trades")
        lots: dict[str, list[dict[str, Any]]] = defaultdict(list)
        closed_results: list[float] = []
        holding_seconds: list[float] = []
        position_sizes: list[float] = []
        for trade in trades:
            row_flags = _loads_list(trade.get("quality_flags_json"))
            flags.extend(str(flag) for flag in row_flags)
            token = trade.get("token_mint")
            side = trade.get("side")
            amount = _float(trade.get("token_amount"))
            price = _float(trade.get("price_usd"))
            if not token or not side or amount is None or price is None:
                flags.append("incomplete_trade_excluded_from_pnl_estimate")
                continue
            notional = amount * price
            position_sizes.append(notional)
            observed_at = _parse_time(trade["observed_at"])
            if side == "buy":
                lots[token].append({"amount": amount, "cost": notional, "time": observed_at})
            elif side == "sell":
                remaining = amount
                proceeds = notional
                cost_basis = 0.0
                while remaining > 0 and lots[token]:
                    lot = lots[token][0]
                    take = min(float(lot["amount"]), remaining)
                    lot_cost = float(lot["cost"]) * (take / float(lot["amount"])) if float(lot["amount"]) else 0
                    cost_basis += lot_cost
                    lot["amount"] = float(lot["amount"]) - take
                    lot["cost"] = float(lot["cost"]) - lot_cost
                    remaining -= take
                    if observed_at and lot.get("time"):
                        holding_seconds.append(max(0, (observed_at - lot["time"]).total_seconds()))
                    if float(lot["amount"]) <= 1e-12:
                        lots[token].pop(0)
                if cost_basis == 0:
                    flags.append("sell_without_observed_entry")
                else:
                    closed_results.append(proceeds - cost_basis)
        wins = [value for value in closed_results if value > 0]
        losses = [abs(value) for value in closed_results if value < 0]
        realized = sum(closed_results) if closed_results else None
        avg_win = mean(wins) if wins else None
        avg_loss = mean(losses) if losses else None
        quality = _metric_quality(flags, trade_count=len(trades), closed_count=len(closed_results))
        now = self.clock.now()
        latest_trade_time = max((_parse_time(row["observed_at"]) for row in trades), default=None)
        metric_id = new_id("wallet_metric")
        await self.database.execute(
            """
            INSERT INTO wallet_metric_snapshots(
              wallet_metric_snapshot_id, wallet, calculated_at, trade_count, closed_trade_count,
              realized_pnl_estimate, unrealized_inventory_json, net_pnl_estimate, win_rate_estimate,
              expectancy_estimate, payoff_ratio, average_win, average_loss, holding_time_summary_json,
              position_sizing_summary_json, sample_size, recency_seconds, evidence_quality, confidence,
              quality_flags_json, source_refs_json, candidate_evidence_only, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
            """,
            (
                metric_id,
                wallet,
                isoformat_utc(now),
                len(trades),
                len(closed_results),
                realized,
                dumps_json({token: lots[token] for token in lots}),
                realized,
                len(wins) / len(closed_results) if closed_results else None,
                mean(closed_results) if closed_results else None,
                (avg_win / avg_loss) if avg_win is not None and avg_loss not in {None, 0} else None,
                avg_win,
                avg_loss,
                dumps_json({"count": len(holding_seconds), "average_seconds": mean(holding_seconds) if holding_seconds else None}),
                dumps_json({"count": len(position_sizes), "average_usd": mean(position_sizes) if position_sizes else None}),
                len(trades),
                (now - latest_trade_time).total_seconds() if latest_trade_time else None,
                quality,
                "medium" if quality == "medium" else "low",
                dumps_json(_unique(flags)),
                dumps_json(_unique(source_refs)),
                isoformat_utc(now),
            ),
        )
        return metric_id

    async def create_wallet_profile(self, wallet: str, metrics_snapshot_id: str | None = None) -> str:
        metric_id = metrics_snapshot_id or await self.calculate_wallet_metrics(wallet)
        metric = await self.database.fetchone("SELECT * FROM wallet_metric_snapshots WHERE wallet_metric_snapshot_id = ?", (metric_id,))
        if not metric:
            raise ValueError(f"wallet metric snapshot not found: {metric_id}")
        flags = list(_loads_list(metric["quality_flags_json"]))
        sample_size = int(metric["sample_size"] or 0)
        win_rate = _float(metric.get("win_rate_estimate"))
        net = _float(metric.get("net_pnl_estimate"))
        label = "unknown_insufficient_evidence"
        label_confidence = "low"
        included: list[str] = []
        excluded: list[str] = []
        candidate_score = None
        if sample_size < 3 or metric["evidence_quality"] == "low":
            excluded.append("insufficient reconstructed high-quality trade sample")
        elif win_rate is not None and net is not None and net > 0:
            label = "smart_money_candidate"
            label_confidence = "medium"
            candidate_score = min(1.0, max(0.0, win_rate * min(sample_size / 20, 1)))
            included.append("positive reconstructed candidate evidence")
        else:
            label = "noisy_wallet"
            label_confidence = "medium"
            excluded.append("candidate evidence does not show repeatable positive reconstructed outcomes")
        profile_id = new_id("wallet_profile")
        now = isoformat_utc(self.clock.now())
        await self.database.execute(
            """
            INSERT INTO wallet_profiles(
              wallet_profile_id, wallet, metrics_snapshot_id, label, label_confidence,
              candidate_score, evidence_quality, degradation_status, sample_size, recency_seconds,
              source_refs_json, explanation_json, included_reasons_json, excluded_reasons_json,
              last_updated_at, candidate_evidence_only, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
            """,
            (
                profile_id,
                wallet,
                metric_id,
                label,
                label_confidence,
                candidate_score,
                metric["evidence_quality"],
                "degraded" if flags else "normal",
                sample_size,
                metric.get("recency_seconds"),
                metric["source_refs_json"],
                dumps_json({"historical_metrics_are_candidate_evidence_only": True}),
                dumps_json(included),
                dumps_json(excluded),
                now,
                now,
            ),
        )
        return profile_id

    async def create_wallet_cluster(
        self,
        *,
        wallets: list[str],
        relation_type: str,
        evidence_refs: list[str],
        confidence: str,
        token_mint: str | None = None,
        flags: list[str] | None = None,
        quality_flags: list[str] | None = None,
    ) -> str:
        cluster_id = new_id("wallet_cluster")
        await self.database.execute(
            """
            INSERT INTO wallet_clusters(
              wallet_cluster_id, relation_type, wallets_json, token_mint, evidence_refs_json,
              confidence, quality_flags_json, flags_json, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                cluster_id,
                relation_type,
                dumps_json(_unique(wallets)),
                token_mint,
                dumps_json(_unique(evidence_refs)),
                confidence,
                dumps_json(_unique(quality_flags or [])),
                dumps_json(_unique(flags or [relation_type])),
                isoformat_utc(self.clock.now()),
            ),
        )
        return cluster_id


def _loads_dict(raw: Any) -> dict[str, Any]:
    if not raw:
        return {}
    parsed = json.loads(raw) if isinstance(raw, str) else raw
    return parsed if isinstance(parsed, dict) else {}


def _loads_list(raw: Any) -> list[Any]:
    if not raw:
        return []
    parsed = json.loads(raw) if isinstance(raw, str) else raw
    return parsed if isinstance(parsed, list) else []


def _text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value)
    return text if text else None


def _float(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return abs(float(value))
    except (TypeError, ValueError):
        return None


def _side(value: Any) -> str | None:
    text = str(value or "").lower()
    if text in {"buy", "sell"}:
        return text
    if "buy" in text:
        return "buy"
    if "sell" in text:
        return "sell"
    return None


def _unique(values: list[Any]) -> list[str]:
    result: list[str] = []
    for value in values:
        text = str(value)
        if text and text not in result:
            result.append(text)
    return result


def _confidence(confidence: str, flags: list[str]) -> str:
    if set(flags) & {"missing_wallet", "uncertain_side", "missing_token_amount", "missing_price_usd", "weak_trade_timestamp"}:
        return "low"
    return confidence if confidence in {"high", "medium"} else "unknown"


def _parse_time(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def _metric_quality(flags: list[str], *, trade_count: int, closed_count: int) -> str:
    if trade_count == 0 or closed_count == 0:
        return "low"
    if set(flags) & {"missing_price_usd", "missing_token_amount", "uncertain_side", "sell_without_observed_entry"}:
        return "low"
    return "medium"
