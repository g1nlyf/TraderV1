from __future__ import annotations

import hashlib
import json
from datetime import datetime
from typing import Any

from walletscarper.stage2.clock import Clock, SystemClock, isoformat_utc
from walletscarper.stage2.db import Stage2Database
from walletscarper.stage2.db.json import dumps_json
from walletscarper.stage2.evidence import EvidenceNormalizer
from walletscarper.stage2.ids import new_id

DEFAULT_TRIAGE_PRIORS: dict[str, Any] = {
    "version": "sprint2-default-v1",
    "notes": "Configurable evidence priors only; not strategy rules or trading truth.",
    "liquidity_usd": {"watching_min": 10_000, "rejected_below": 1_000},
    "market_cap": {"watching_min": 20_000, "giant_above": 50_000_000},
    "token_age_seconds": {"watching_min": 60, "archive_above": 30 * 24 * 3600},
    "volume_24h": {"watching_min": 5_000},
    "txns_1h": {"watching_min": 10},
    "holder_count": {"watching_min": None},
    "source_confidence": {"minimum_for_watching": "medium"},
    "data_completeness": {"required_for_watching": ["token_mint", "pool_address", "latest_observed_at"]},
}


class TokenIntelligenceService:
    def __init__(self, database: Stage2Database, clock: Clock | None = None):
        self.database = database
        self.clock = clock or SystemClock()

    async def scan_token_candidates_from_raw_events(self, *, limit: int = 100) -> dict[str, Any]:
        rows = await self.database.fetchall(
            """
            SELECT r.raw_source_event_id
            FROM raw_source_events r
            LEFT JOIN normalized_evidence_refs e
              ON e.raw_source_event_id = r.raw_source_event_id
             AND e.normalized_type = 'token_candidate'
            WHERE e.normalized_evidence_ref_id IS NULL
            ORDER BY r.ingested_at, r.raw_source_event_id
            LIMIT ?
            """,
            (limit,),
        )
        normalizer = EvidenceNormalizer(self.database, clock=self.clock)
        raw_events_seen = len(rows)
        token_candidates_created = 0
        profiles_created = 0
        triage_decisions_created = 0
        quality_flags: list[str] = []
        config_id = await self.create_default_triage_config()
        for row in rows:
            result = await normalizer.normalize_raw_source_event(row["raw_source_event_id"])
            quality_flags.extend(result.quality_flags)
            for candidate_id in result.token_candidate_ids:
                token_candidates_created += 1
                profile_id = await self.create_profile_from_candidate(candidate_id)
                profiles_created += 1
                await self.triage_token_profile(profile_id, config_id)
                triage_decisions_created += 1
        return {
            "raw_events_seen": raw_events_seen,
            "token_candidates_created": token_candidates_created,
            "profiles_created": profiles_created,
            "triage_decisions_created": triage_decisions_created,
            "quality_flags": _unique(quality_flags),
            "trading_decisions_created": 0,
        }

    async def create_profile_from_candidate(self, token_candidate_id: str) -> str:
        candidate = await self.database.fetchone("SELECT * FROM token_candidates WHERE token_candidate_id = ?", (token_candidate_id,))
        if not candidate:
            raise ValueError(f"token candidate not found: {token_candidate_id}")
        snapshots = await self.database.fetchall(
            """
            SELECT * FROM market_snapshots
            WHERE token_candidate_id = ? OR token_mint = ?
            ORDER BY observed_at DESC, created_at DESC
            """,
            (token_candidate_id, candidate.get("token_mint")),
        )
        latest = snapshots[0] if snapshots else None
        source_refs = _unique(
            list(_loads_list(candidate.get("raw_event_refs_json")))
            + [row["raw_source_event_id"] for row in snapshots if row.get("raw_source_event_id")]
            + [row["market_snapshot_id"] for row in snapshots if row.get("market_snapshot_id")]
        )
        flags = _unique(list(_loads_list(candidate.get("quality_flags_json"))) + _collect_snapshot_flags(snapshots))
        latest_observed = latest.get("observed_at") if latest else candidate["discovered_at"]
        discovered_at = candidate.get("discovered_at")
        age_seconds = _age_seconds(discovered_at, latest_observed)
        token_mint = candidate.get("token_mint") or (latest.get("token_mint") if latest else None)
        pool_address = latest.get("pool_address") if latest else None
        if not token_mint:
            flags.append("missing_token_mint")
        if not pool_address:
            flags.append("missing_pool_address")
        if latest and latest.get("liquidity_usd") is None:
            flags.append("missing_liquidity_usd")
        if latest and latest.get("price_usd") is None:
            flags.append("missing_price_usd")
        evidence_quality = _evidence_quality(flags, confidence=str(candidate.get("confidence") or "unknown"))
        degradation_status = _degradation_status(flags)
        eligible = bool(candidate.get("eligible_for_high_confidence_evaluation")) and bool(
            latest and latest.get("eligible_for_high_confidence_evaluation")
        ) and evidence_quality in {"high", "medium"}
        profile_id = new_id("token_profile")
        await self.database.execute(
            """
            INSERT INTO token_profiles(
              token_profile_id, token_candidate_id, token_mint, pool_address, chain, ecosystem,
              symbol, name, discovered_at, latest_observed_at, age_seconds, market_cap, fdv,
              liquidity_usd, volume_24h, txns_1h, holder_count, top_holder_concentration,
              source_refs_json, evidence_quality, confidence, quality_flags_json,
              degradation_status, eligible_for_high_confidence_evaluation, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                profile_id,
                token_candidate_id,
                token_mint,
                pool_address,
                candidate.get("chain") or (latest.get("chain") if latest else None),
                candidate.get("ecosystem"),
                candidate.get("symbol"),
                candidate.get("name"),
                discovered_at,
                latest_observed,
                age_seconds,
                latest.get("market_cap") if latest else None,
                latest.get("fdv") if latest else None,
                latest.get("liquidity_usd") if latest else None,
                latest.get("volume_24h") if latest else None,
                latest.get("txns_1h") if latest else None,
                latest.get("holder_count") if latest else None,
                None,
                dumps_json(source_refs),
                evidence_quality,
                _combined_confidence(str(candidate.get("confidence") or "unknown"), flags),
                dumps_json(_unique(flags)),
                degradation_status,
                1 if eligible else 0,
                isoformat_utc(self.clock.now()),
            ),
        )
        return profile_id

    async def create_default_triage_config(self, *, version_label: str = "sprint2-default-v1") -> str:
        content = dict(DEFAULT_TRIAGE_PRIORS)
        content["version"] = version_label
        content_hash = hashlib.sha256(dumps_json(content).encode("utf-8")).hexdigest()
        existing = await self.database.fetchone("SELECT * FROM token_triage_configs WHERE content_hash = ?", (content_hash,))
        if existing:
            return str(existing["token_triage_config_id"])
        config_id = new_id("token_triage_config")
        await self.database.execute(
            """
            INSERT INTO token_triage_configs(token_triage_config_id, version_label, content_hash, bucket_priors_json, notes, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                config_id,
                version_label,
                content_hash,
                dumps_json(content),
                "Configurable Sprint 2 evidence priors; not a trading strategy.",
                isoformat_utc(self.clock.now()),
            ),
        )
        return config_id

    async def triage_token_profile(self, token_profile_id: str, token_triage_config_id: str | None = None) -> str:
        profile = await self.database.fetchone("SELECT * FROM token_profiles WHERE token_profile_id = ?", (token_profile_id,))
        if not profile:
            raise ValueError(f"token profile not found: {token_profile_id}")
        config_id = token_triage_config_id or await self.create_default_triage_config()
        config = await self.database.fetchone("SELECT * FROM token_triage_configs WHERE token_triage_config_id = ?", (config_id,))
        if not config:
            raise ValueError(f"token triage config not found: {config_id}")
        priors = _loads_dict(config["bucket_priors_json"])
        flags = list(_loads_list(profile["quality_flags_json"]))
        buckets = _bucket_assignments(profile, priors)
        reasons: list[str] = []
        no_trade_reason = None
        status = "triage_pending"
        if profile["evidence_quality"] in {"low", "unavailable"}:
            status = "rejected"
            no_trade_reason = "insufficient evidence quality"
            reasons.append(no_trade_reason)
        elif profile.get("liquidity_usd") is not None and float(profile["liquidity_usd"]) < float(priors["liquidity_usd"]["rejected_below"]):
            status = "rejected"
            no_trade_reason = "liquidity below configured evidence prior"
            reasons.append(no_trade_reason)
        elif bool(profile.get("eligible_for_high_confidence_evaluation")) and _meets_watch_priors(profile, priors):
            status = "watching"
            reasons.append("profile meets configured watching evidence priors")
        else:
            status = "triage_pending"
            reasons.append("profile needs more evidence before watching")
        decision_id = new_id("token_triage_decision")
        await self.database.execute(
            """
            INSERT INTO token_triage_decisions(
              token_triage_decision_id, token_profile_id, token_candidate_id, token_triage_config_id,
              decision_status, reasons_json, bucket_assignments_json, no_trade_reason, confidence,
              quality_flags_json, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                decision_id,
                token_profile_id,
                profile.get("token_candidate_id"),
                config_id,
                status,
                dumps_json(reasons),
                dumps_json(buckets),
                no_trade_reason,
                profile["confidence"],
                dumps_json(flags),
                isoformat_utc(self.clock.now()),
            ),
        )
        return decision_id


def _loads_list(raw: Any) -> list[Any]:
    if not raw:
        return []
    parsed = json.loads(raw) if isinstance(raw, str) else raw
    return parsed if isinstance(parsed, list) else []


def _loads_dict(raw: Any) -> dict[str, Any]:
    if not raw:
        return {}
    parsed = json.loads(raw) if isinstance(raw, str) else raw
    return parsed if isinstance(parsed, dict) else {}


def _unique(values: list[Any]) -> list[str]:
    result: list[str] = []
    for value in values:
        text = str(value)
        if text and text not in result:
            result.append(text)
    return result


def _collect_snapshot_flags(snapshots: list[dict[str, Any]]) -> list[str]:
    flags: list[str] = []
    for snapshot in snapshots:
        flags.extend(str(flag) for flag in _loads_list(snapshot.get("quality_flags_json")))
    return _unique(flags)


def _age_seconds(start: str | None, end: str | None) -> float | None:
    if not start or not end:
        return None
    try:
        start_dt = datetime.fromisoformat(str(start).replace("Z", "+00:00"))
        end_dt = datetime.fromisoformat(str(end).replace("Z", "+00:00"))
    except ValueError:
        return None
    return max(0, (end_dt - start_dt).total_seconds())


def _evidence_quality(flags: list[str], *, confidence: str) -> str:
    disqualifying = {"missing_observed_at", "missing_token_mint", "missing_pool_address", "source_unavailable"}
    degraded = {"missing_price_usd", "missing_liquidity_usd", "source_degraded", "stale_source_data", "weak_timestamp_provenance"}
    if disqualifying & set(flags) or confidence == "unknown":
        return "low"
    if degraded & set(flags) or confidence == "low":
        return "medium"
    return "high" if confidence == "high" else "medium"


def _degradation_status(flags: list[str]) -> str:
    if "source_unavailable" in flags:
        return "unavailable"
    if set(flags) & {"source_degraded", "stale_source_data", "weak_timestamp_provenance"}:
        return "degraded"
    if set(flags) & {"missing_price_usd", "missing_liquidity_usd", "missing_pool_address", "missing_token_mint"}:
        return "partial"
    return "normal"


def _combined_confidence(confidence: str, flags: list[str]) -> str:
    if _evidence_quality(flags, confidence=confidence) == "low":
        return "low"
    return confidence if confidence in {"high", "medium"} else "unknown"


def _bucket_assignments(profile: dict[str, Any], priors: dict[str, Any]) -> dict[str, str]:
    return {
        "liquidity": _bucket_number(profile.get("liquidity_usd"), priors["liquidity_usd"]["watching_min"]),
        "market_cap": _bucket_number(profile.get("market_cap"), priors["market_cap"]["watching_min"]),
        "token_age": _bucket_number(profile.get("age_seconds"), priors["token_age_seconds"]["watching_min"]),
        "volume": _bucket_number(profile.get("volume_24h"), priors["volume_24h"]["watching_min"]),
        "tx_velocity": _bucket_number(profile.get("txns_1h"), priors["txns_1h"]["watching_min"]),
        "source_confidence": str(profile.get("confidence") or "unknown"),
        "data_completeness": str(profile.get("evidence_quality") or "unknown"),
    }


def _bucket_number(value: Any, threshold: Any) -> str:
    if value is None or threshold is None:
        return "unknown"
    try:
        return "meets_prior" if float(value) >= float(threshold) else "below_prior"
    except (TypeError, ValueError):
        return "unknown"


def _meets_watch_priors(profile: dict[str, Any], priors: dict[str, Any]) -> bool:
    checks = [
        _meets(profile.get("liquidity_usd"), priors["liquidity_usd"]["watching_min"]),
        _meets(profile.get("volume_24h"), priors["volume_24h"]["watching_min"]),
        _meets(profile.get("txns_1h"), priors["txns_1h"]["watching_min"]),
        str(profile.get("confidence")) in {"high", "medium"},
    ]
    return all(checks)


def _meets(value: Any, threshold: Any) -> bool:
    if value is None or threshold is None:
        return False
    try:
        return float(value) >= float(threshold)
    except (TypeError, ValueError):
        return False
