# Wallet Funnel And Market Loop

## Wallet Funnel

The wallet funnel is the most important V2.0 data pipeline.

```mermaid
flowchart TD
    A["Selected token"] --> B["Parse all available token trades"]
    B --> C["Extract wallets"]
    C --> D["Token-specific P&L/ROI prefilter"]
    D --> E["Wallet recent-history profiler"]
    E --> F["Deterministic quality metrics"]
    F --> G["Wallet Intelligence Agent review"]
    G --> H["Ranked wallet database"]
    H --> I["Tracked wallet monitor"]
    I --> J["Wallet signal stream"]
    J --> K["Hermes active market session"]
```

## Token-Specific Prefilter

The prefilter exists to remove obvious noise before the Wallet Intelligence Agent spends reasoning budget.

Suggested evidence thresholds are priors, not final decisions:

- token-specific ROI above 20%;
- non-trivial realized profit/notional size;
- complete or reconstructable buy/sell path;
- timestamp quality sufficient to avoid hindsight;
- not only one dust trade;
- not immediately bot-like from transaction frequency.

Higher ROI buckets should be preserved, for example 20-50%, 50-100%, 100-200%, 200%+. The agent should see the bucket and context, not just a binary pass/fail.

## Broader Wallet Profiler

After token-specific prefilter, scripts must pull recent wallet history across months.

Minimum outputs:

- realized P&L estimate by token;
- total realized P&L estimate;
- net P&L after fees/slippage assumptions when possible;
- win rate estimate;
- closed trade count;
- average win, average loss and payoff ratio;
- holding time distribution;
- position size distribution;
- liquidity at entry and exit;
- one-token concentration;
- repeated token category behavior;
- copyability delay tolerance;
- suspicious behavior flags;
- data quality flags and missing evidence.

The profiler is deterministic. It can say "this wallet had positive estimated P&L and 61% win rate over 43 closed trades". It must not say "therefore track this wallet" as the final decision.

## Wallet Database

The ranked wallet database must store both deterministic metrics and agent judgment.

Required views:

- active elite wallets;
- probation wallets;
- watch-only wallets;
- rejected wallets with reasons;
- archived/stale wallets;
- wallet clusters;
- wallet rank history;
- forward contribution to paper/shadow P&L;
- demotion and promotion events.

Required invariant:

```text
A wallet enters the elite tracking set only through explicit Wallet Intelligence Agent review plus deterministic evidence refs.
```

## Wallet Personality Model

Hermes must build a compact behavioral model for each tracked wallet.

Examples:

- early entry, patient exit, medium notional;
- fast scalper, too difficult to copy;
- one-token lucky winner;
- cluster participant, possibly coordinated;
- insider-like early buyer;
- reliable trend confirmer;
- late exit signal only;
- strong in low-liquidity tokens but weak in high-volume tokens.

This personality model is not cosmetic. It tells Hermes how to interpret a signal:

- buy signal from an early hunter has different meaning than buy signal from a late confirmer;
- sell signal from a fast scalper may be less relevant for a longer paper thesis;
- multiple correlated wallets may count as one cluster, not many independent confirmations.

## Active Market Loop

When Hermes sees a wallet signal or a Token Selection Agent active-watch decision, it starts an active market session.

Required session inputs:

- token profile;
- current and recent 1-second candles or snapshots;
- liquidity and route quality;
- tracked wallet entries/exits;
- recent holder/transaction changes when available;
- source freshness;
- open paper position state;
- prior outcome patterns for similar sessions.

Cadence:

- market data collector: target 1-second snapshots/candles for active tokens;
- Hermes review loop: configurable, usually 2-10 seconds depending on latency and token risk;
- exit checks: priority over new entries;
- token research: lower priority than open position monitoring.

Hermes should not need to open a browser every time. Browser research is a tool for missing facts, semi-structured pages and cross-checking. API/indexer data is preferred for canonical market facts.

## Exit Signals

Tracked wallet exits are a first-class evidence stream.

Hermes should observe:

- whether the source wallet exits;
- whether other elite wallets exit;
- whether exits cluster in time;
- whether liquidity deteriorates;
- whether price action confirms or contradicts the exit;
- whether the wallet's historical personality makes its exit relevant.

Exit decisions must be recorded before simulated exit fills. Deterministic risk and paper/shadow execution remain mandatory.
