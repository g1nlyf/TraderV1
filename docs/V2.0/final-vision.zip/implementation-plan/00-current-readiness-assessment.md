# Current Readiness Assessment

## Summary

The current project is a strong Stage 2 foundation, but it is not yet the final V2.0 agentic trading system described by the user.

What exists:

- legacy wallet/token collector;
- deterministic Stage 2 schemas and services;
- risk-gated paper workflow;
- jobs, leases, monitoring sessions, strategy and memory artifacts;
- shadow-readiness evidence tables;
- local dashboard and Windows launch scripts;
- Hermes installed and connected to a read-only operator plugin.

What is missing:

- Hermes as autonomous trading orchestrator;
- AI token selection as a first-class decision loop;
- AI wallet selection/rating database as the main edge layer;
- full token-to-wallet funnel at production depth;
- broad multi-month wallet history profiler;
- tracked-wallet realtime transaction stream;
- second-level active market loop controlled by Hermes;
- write-safe Hermes tools for decisions, signals, risk and paper/shadow workflow;
- forward wallet competition and learning loop tied to agent decisions.

## Evidence From Repo

| Area | Current state | Evidence |
|---|---|---|
| Legacy token discovery | Exists | `WalletScarper/walletscarper/services/discovery.py` uses DexScreener and GeckoTerminal |
| Legacy transaction parsing | Exists but bounded | `WalletScarper/walletscarper/services/transactions.py` parses pool trades from DexPaprika/GeckoTerminal and optional Solana RPC signer lookup |
| Legacy wallet scoring | Exists | `WalletScarper/walletscarper/services/scoring.py`, `wallet_quality.py`, `tracked_wallets` tables |
| Legacy scheduler | Exists | `WalletScarper/walletscarper/scheduler.py` runs discovery, backfill, live monitor, Telegram, Bitquery if configured |
| Stage 2 deterministic schema | Exists | `WalletScarper/walletscarper/stage2/db/migrations.py` migrations 1-8 |
| Token profile/triage | Exists as deterministic evidence layer | `walletscarper/stage2/token_intelligence/service.py` |
| Wallet metrics/profile | Exists as deterministic candidate evidence | `walletscarper/stage2/wallet_intelligence/service.py` |
| Signal/risk/paper workflow | Exists | `signals/service.py`, `risk/service.py`, `paper_trading/service.py` |
| Strategy/memory | Exists | `strategy/service.py`, `memory/service.py`, `reviews/service.py` |
| Shadow evidence | Partial | `shadow_readiness/service.py`; current reports still show gaps |
| Hermes runtime | Exists | `external/hermes-agent`, `scripts/run-hermes.bat` |
| Hermes project tools | Read-only only | `.hermes/plugins/traderv1_operator` exposes health/reports/shadow summary |
| Stage 2 acceptance | Accepted with gaps | `docs/implementation-progress/reports/final-acceptance-report.md` |
| Stage 3 readiness | Not accepted | `docs/implementation-progress/reports/shadow-mode-gap-report.md` |

## Architectural Mismatch

The current system still leans toward script-generated scoring:

- legacy `DiscoveryService` assigns `signal_score` and priority;
- legacy `ScoringService` promotes wallets into `tracked_wallets`;
- Hermes currently inspects reports instead of controlling the workflow;
- current tools do not let Hermes ask for token parsing, wallet profiling, agent reviews, signals or paper actions.

These pieces are still useful, but V2.0 must wrap them as evidence/tooling under agent control.

## Readiness By Target Agent

| Target agent | Ready pieces | Missing pieces | Readiness |
|---|---|---|---|
| Token Selection Agent | Token candidates, profiles, triage configs, market snapshots | Agent decision artifact, richer holder/growth metrics, active token watchlist, Hermes tools | Partial |
| Wallet Intelligence Agent | Wallet trades, metrics, profiles, clusters, legacy scoring | Agent wallet reviews, elite wallet DB, multi-month history depth, token-specific ROI funnel, forward contribution | Partial |
| Hermes Trading Orchestrator | Signal/risk/paper/evaluation services, reports, Hermes runtime | Write-safe tools, active sessions, second-level market loop, tracked-wallet signal stream, decision artifacts | Low to partial |
| Deterministic risk/accounting | Strong paper-only foundation | Real observation windows, route/fill comparison evidence for shadow confidence | Good for paper, partial for shadow |
| Continuous operation | Legacy APScheduler, Windows scripts | Stage 2/V2 daemon and durable worker loop for agent tasks | Partial |

## Baseline Conclusion

Do not throw away Stage 2. Use it as the deterministic core. But the next implementation must explicitly shift the product center from "scripts score wallets/tokens" to "Hermes orchestrates token, wallet and trading decisions using scripts as tools".
