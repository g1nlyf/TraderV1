# Missing Capabilities For V2.0

## Critical Gaps

### 1. Hermes Is Not Yet The Trading Orchestrator

Current Hermes tools are read-only health/report tools. V2.0 requires Hermes tools that can safely create jobs, agent decisions, signals, no-trades, risk check requests, paper/shadow orders, exit decisions, reviews and memory proposals.

Needed:

- update Hermes role from Project Operator Assistant to Trading Research Director;
- implement write-safe typed tools;
- keep deterministic services as authority for risk/accounting;
- preserve full audit trail.

### 2. Token Selection Agent Is Not Implemented

Current token triage is deterministic evidence bucketing. It is not an AI agent choosing the best current tokens.

Needed:

- `TokenAgentDecision` records;
- richer token profile inputs: holders, concentration, market cap/FDV, growth windows, liquidity/route quality, source freshness;
- token active/passive watchlists;
- Hermes-accessible token scan and decision tools.

### 3. Wallet Funnel Is Too Shallow

Current code can reconstruct wallet trades from available raw events and score legacy pool transactions. It does not yet guarantee full token trade corpus extraction, all wallets for selected tokens, token-specific profitable-wallet filtering and broad multi-month wallet history.

Needed:

- token trade corpus per selected token/pool;
- `WalletTokenOutcome` records;
- full recent wallet history profiler;
- data-source strategy for wallets beyond a single pool;
- stronger sample-size, concentration and copyability checks.

### 4. Wallet Intelligence Agent Review Is Missing

Current wallet profiles are deterministic candidate labels. The final vision requires an AI agent that writes wallet ratings, reasons and behavioral profiles.

Needed:

- `AgentWalletReview`;
- elite/probation/watch/reject database;
- "why yes", "why no", demotion triggers;
- wallet personality model;
- forward contribution calculations by wallet.

### 5. Tracked Wallet Signals Are Not Real-Time Enough

Legacy `LiveMonitor` checks the latest known row in `pool_transactions`. It does not independently stream every tracked wallet transaction.

Needed:

- tracked-wallet monitor against Solana/indexer/Bitquery/Helius-compatible sources;
- transaction event bus;
- dedupe and latency measurement;
- buy and sell signal handling;
- wallet-cluster signal collapsing.

### 6. Second-Level Market Loop Is Missing

Current calibration wrappers can record quote observations, but Hermes does not control a 1-second active market loop.

Needed:

- active token sessions;
- 1-second snapshots/candles for active tokens where sources support it;
- recent-window query tool;
- 2-10 second Hermes review loop;
- exit-priority queueing;
- stale-data blocks.

### 7. Forward Learning Is Not Connected To Agent Choices

Stage 2 can calculate paper outcomes and strategy metrics, but it does not yet attribute performance to token agent choices, wallet reviews and Hermes trading decisions.

Needed:

- `AgentTradingDecision` records linked to `Signal`/`NoTradeSignal`;
- wallet forward contribution reports;
- token selection outcome reports;
- strategy comparison by agent decision class;
- memory proposals from post-trade reviews.

### 8. Shadow Readiness Remains Gap-Blocked

The current reports explicitly say Stage 3 shadow readiness is `gap_report_required`.

Needed:

- real observation-window evidence;
- source quote freshness;
- latency distribution;
- route-quality model;
- fill-vs-quote comparison with contemporaneous quotes.

## Important Non-Gaps

The project does not need real live execution for V2.0. It also does not need a new general multi-agent framework before the tool surface, wallet funnel and active market loop exist.

## Win Rate Decision

Win rate should be included and usually positive for wallet admission, but it must not be the main target.

Use it as:

- repeatability check;
- sample-quality check;
- lucky-wallet filter;
- payoff-ratio context;
- demotion signal when it collapses in forward testing.

Do not use it as:

- direct buy/sell rule;
- replacement for net P&L;
- proof of edge without sample size and costs.
