# Two Sprint Implementation Plan

## Sprint 1: Agentic Token And Wallet Intelligence Foundation

### Goal

Build the V2 evidence and decision foundation so Token Selection Agent and Wallet Intelligence Agent can operate over real structured artifacts rather than legacy script scores.

### Deliverables

1. Add V2 schema extensions:
   - `token_agent_decisions`;
   - `token_trade_corpora`;
   - `wallet_token_outcomes`;
   - `agent_wallet_reviews`;
   - `wallet_forward_contributions`;
   - `active_token_sessions`;
   - `agent_trading_decisions`.

2. Normalize legacy outputs into Stage 2/V2 evidence:
   - map legacy `tokens`, `pools`, `token_snapshots`, `pool_transactions`, `wallet_scores`, `tracked_wallets` into append-only V2-compatible artifacts;
   - preserve legacy tables as adapter state, not source of truth.

3. Implement token intelligence upgrade:
   - holder count and concentration fields where data source supports it;
   - market cap/FDV/liquidity/volume growth windows;
   - tradeability and source-quality summaries;
   - `TokenAgentDecision` service.

4. Implement token trade corpus:
   - fetch recent available trades for selected token/pool;
   - store corpus metadata and coverage;
   - derive wallet list from corpus;
   - mark coverage gaps honestly.

5. Implement wallet funnel prefilter:
   - calculate token-specific wallet ROI/P&L;
   - bucket ROI from 20% upward;
   - require notional/sample/timestamp quality;
   - produce `WalletTokenOutcome`.

6. Implement broader wallet profiler:
   - recent multi-token history;
   - total P&L estimate;
   - win rate estimate;
   - average win/loss, payoff ratio, holding time, position size, concentration;
   - bot-like and copyability flags;
   - source-quality output.

7. Implement Wallet Intelligence Agent review storage:
   - `AgentWalletReview` service;
   - elite/probation/watch/reject decisions;
   - reasons, behavioral profile and demotion triggers.

8. Add Hermes tools for Token and Wallet agents:
   - `token.scan_universe`;
   - `token.get_profile`;
   - `token.request_deep_parse`;
   - `token.record_agent_decision`;
   - `wallet.extract_from_token`;
   - `wallet.profile_history`;
   - `wallet.get_metrics`;
   - `wallet.record_agent_review`;
   - `wallet.list_elite`.

### Acceptance Gates

- A selected token can produce a trade corpus, wallet candidates and token-specific wallet outcomes.
- A candidate wallet can be profiled across recent history with P&L and win rate estimates.
- Wallet Intelligence Agent can store include/reject/probation decisions with reasons.
- Hermes can call token/wallet tools without raw SQL and without mutating paper ledger.
- No paper order is created in Sprint 1.
- Existing Stage 2 tests still pass.

## Sprint 2: Hermes Orchestrator, Active Market Loop And Paper/Shadow Learning

### Goal

Turn Hermes into the active Trading Orchestrator that combines wallet signals, token sessions, second-level market data and prior outcomes to make paper/shadow decisions.

### Deliverables

1. Update Hermes persona and toolset:
   - replace read-only operator framing with Trading Research Director framing;
   - preserve forbidden live/private-key boundaries;
   - add write-safe tools from `almanac-v2/02-hermes-tool-contracts.md`.

2. Implement tracked wallet signal stream:
   - monitor elite/probation wallets for buys and sells;
   - dedupe transactions;
   - measure source/event latency;
   - collapse correlated cluster signals;
   - emit signal events to jobs/sessions.

3. Implement active token session engine:
   - `ActiveTokenSession` lifecycle;
   - 1-second market snapshot/candle collector for active tokens;
   - recent-window query;
   - source health and stale-data gating;
   - exit checks prioritized over new research.

4. Implement Hermes trading decision workflow:
   - create `AgentTradingDecision`;
   - link decision to token, wallets, market snapshots, browser/API evidence and memory;
   - create `Signal` or `NoTradeSignal`;
   - request deterministic risk;
   - request paper/shadow order only after passed risk;
   - record wait/skip/downgrade decisions.

5. Implement exit orchestration:
   - observe tracked wallet sells;
   - combine exit signals with market state and wallet personality;
   - create `ExitDecision`;
   - request exit risk check;
   - simulate exit fill;
   - calculate outcome.

6. Implement forward learning:
   - calculate wallet forward contribution;
   - calculate token selection outcome;
   - attribute paper outcomes to Hermes decision class;
   - create post-trade review and memory proposals;
   - update wallet demotion/promotion candidates.

7. Implement continuous run mode:
   - Stage 2/V2 worker daemon;
   - durable leases and recovery;
   - health dashboard additions;
   - final V2 acceptance command.

### Acceptance Gates

- A tracked wallet buy can trigger an active token session.
- Hermes can observe market data over repeated seconds and choose signal/no-trade/wait.
- Risk engine can veto Hermes decisions.
- A complete paper/shadow entry and exit can be produced from Hermes decisions.
- Wallet exits can influence exit decisions without being hardcoded as automatic exits.
- Agent decisions, paper outcomes and wallet contribution reports are linked.
- A V2 acceptance report clearly separates paper success, shadow gaps and any missing live-readiness evidence.
- No private keys, signer, DEX transaction builder or real live execution path exists.

## Completion Definition

After Sprint 2, the system should match the requested concept:

- AI agent selects tokens.
- AI agent selects and rates wallets.
- Hermes orchestrates market decisions from combined evidence.
- Scripts are data/tools, not the trader.
- Best wallets compete in a maintained database.
- The system learns through forward paper/shadow P&L, not retrospective stories.
